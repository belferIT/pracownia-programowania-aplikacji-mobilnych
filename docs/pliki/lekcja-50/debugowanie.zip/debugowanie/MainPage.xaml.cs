namespace Debugowanie;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnObliczClicked(object? sender, EventArgs e)
    {
        string[] czesci = entOceny.Text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        int[] oceny = new int[czesci.Length];

        for (int i = 0; i <= czesci.Length; i++)
        {
            oceny[i] = int.Parse(czesci[i]);
        }

        int suma = 0;
        int najwyzsza = 0;
        foreach (int ocena in oceny)
        {
            if (ocena < 1 && ocena > 6)
            {
                lblWynik.Text = $"Ocena {ocena} jest spoza skali 1–6";
                return;
            }
            suma += ocena;
            if (ocena > najwyzsza)
            {
                najwyzsza = ocena;
            }
        }

        double srednia = suma / oceny.Length;
        string wyroznienie = srednia > 4.75 ? "TAK" : "NIE";

        lblWynik.Text = $"Średnia: {srednia:F2}\nNajwyższa: {najwyzsza}\nWyróżnienie: {wyroznienie}";
    }
}
